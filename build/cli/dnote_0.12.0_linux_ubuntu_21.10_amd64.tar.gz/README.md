This directory contains the command line interface project for Dnote.
